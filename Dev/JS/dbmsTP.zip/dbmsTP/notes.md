https://www.mysqltutorial.org/mysql-nodejs/select/
https://www.sqltutorial.org/sql-add-column/
https://www.w3schools.com/sql/sql_datatypes.asp
https://stackoverflow.com/questions/62260725/er-not-supported-auth-mode-client-does-not-support-authentication-protocol-requ
https://stackoverflow.com/questions/52815608/er-not-supported-auth-mode-client-does-not-support-authentication-protocol-requ


from the rrot directory where server is installed: C:\Program Files\MySQL\MySQL Server 8.0\bin
> ./mysql -u root -p
Enter password: ********